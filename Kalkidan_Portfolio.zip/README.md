# Kalkidan's Portfolio

Responsive single-page portfolio featuring 11 GitHub repositories, project case studies, filters, GitHub API metadata, a downloadable resume, LinkedIn and contact links.

## Publish using GitHub Pages

1. Create a **public** repository named `kalkidan9292.github.io` under the `kalkidan9292` account.
2. Upload `index.html`, `Resume.pdf`, and `projects.json` to the repository root.
3. Open **Settings → Pages → Build and deployment**. Choose **Deploy from a branch**, branch **main**, folder **/(root)**, then **Save**.
4. Wait for deployment, then visit `https://kalkidan9292.github.io`.

Before publishing, verify resume details and make sure every public project is ready for recruiters.
